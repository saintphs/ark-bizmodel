Color Logo Maker v1.0
==================================================================
Copyright � 2009 Igor Tolmachev, IT Samples.
http://www.itsamples.com
All Rights Reserved.
==================================================================

Color Logo Maker is a simple utility which can generate color-cycling
logo (Google-like) for your web site. Color Logo Maker allows you to
adjust various parameters like a font, the text, a "color cycling 
scheme", background, shadow and so on.

If you encounter a problem while running this utility,
please record all the information and send it to:
support@itsamples.com